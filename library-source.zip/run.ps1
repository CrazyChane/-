$ErrorActionPreference='Stop'
Set-Location $PSScriptRoot
$libraryPhp=(Get-Command php -ErrorAction SilentlyContinue).Source
if(-not $libraryPhp -and (Test-Path 'C:/xampp/php/php.exe')) {$libraryPhp='C:/xampp/php/php.exe'}
if(-not $libraryPhp) {throw 'Установите PHP 8.0+ с PDO SQLite и mbstring.'}
if(-not (Test-Path 'storage/library.sqlite')) {
 $librarySecure=Read-Host 'Новый пароль администратора (от 12 символов)' -AsSecureString
 $env:ADMIN_PASSWORD=[System.Net.NetworkCredential]::new('', $librarySecure).Password
 & $libraryPhp bin/install.php
 Remove-Item Env:ADMIN_PASSWORD
}
Write-Host 'Откройте http://127.0.0.1:8086. Для остановки нажмите Ctrl+C.'
& $libraryPhp -S 127.0.0.1:8086 -t public
