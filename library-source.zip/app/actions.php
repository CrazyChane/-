<?php
if($_SERVER['REQUEST_METHOD']!=='POST') return;
if(!hash_equals(csrf(),(string)($_POST['csrf'] ?? ''))) {http_response_code(419);exit('Сессия устарела. Обновите страницу.');}
$action=(string)($_POST['action'] ?? '');
$target='catalog';
try {
 if($action==='register') {
  $name=trim($_POST['name'] ?? '');$email=mb_strtolower(trim($_POST['email'] ?? ''));$password=$_POST['password'] ?? '';
  if(mb_strlen($name)<2 || mb_strlen($name)>100 || strlen($email)>190 || !filter_var($email,FILTER_VALIDATE_EMAIL) || strlen($password)<12 || strlen($password)>72) throw new DomainException('Укажите имя, корректный email и пароль от 12 до 72 байт.');
  if(query('SELECT id FROM users WHERE email=?',[$email])->fetch()) throw new DomainException('Этот email уже зарегистрирован.');
  query('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)',[$name,$email,password_hash($password,PASSWORD_DEFAULT)]);
  session_regenerate_id(true);$_SESSION['uid']=(int)$db->lastInsertId();$_SESSION['csrf']=bin2hex(random_bytes(32));
  $_SESSION['flash']='Регистрация завершена. Добро пожаловать!';
 } elseif($action==='login') {
  $now=time();$attempts=$_SESSION['attempts'] ?? []; $attempts=array_values(array_filter($attempts,fn($x)=>$x>$now-900));
  if(count($attempts)>=8) throw new DomainException('Слишком много попыток. Повторите через 15 минут.');
  $u=query('SELECT * FROM users WHERE email=?',[mb_strtolower(trim($_POST['email'] ?? ''))])->fetch();
  if(!$u || !password_verify($_POST['password'] ?? '',$u['password_hash'])) {$_SESSION['attempts']=[...$attempts,$now];throw new DomainException('Неверный email или пароль.');}
  session_regenerate_id(true);$_SESSION['uid']=$u['id'];$_SESSION['attempts']=[];$_SESSION['csrf']=bin2hex(random_bytes(32));$_SESSION['flash']='Вы вошли в систему.';
 } elseif($action==='logout') {$_SESSION=[];session_regenerate_id(true);}
 elseif($action==='request') {
  $u=requireUser();$id=(int)($_POST['book_id'] ?? 0);
  if(!query('SELECT id FROM books WHERE id=?',[$id])->fetch()) throw new DomainException('Книга не найдена.');
  if(!available($id)) throw new DomainException('Книга уже выдана.');
  if(query("SELECT id FROM requests WHERE user_id=? AND book_id=? AND status='pending'",[$u['id'],$id])->fetch()) throw new DomainException('Заявка уже ожидает решения.');
  query('INSERT INTO requests(user_id,book_id) VALUES(?,?)',[$u['id'],$id]);$_SESSION['flash']='Заявка отправлена библиотекарю.';$target='my';
 } elseif($action==='cancel') {
  $u=requireUser();query("UPDATE requests SET status='cancelled',resolved_at=CURRENT_TIMESTAMP WHERE id=? AND user_id=? AND status='pending'",[(int)$_POST['id'],$u['id']]);$target='my';$_SESSION['flash']='Заявка отменена.';
 } elseif(in_array($action,['save_book','delete_book','issue','reject','extend','return'],true)) {
  $admin=requireUser(true);$target='manage';$id=(int)($_POST['id'] ?? 0);
  if($action==='save_book') {
   $values=[];foreach(['title'=>200,'author'=>150,'genre'=>80,'isbn'=>20] as $key=>$max) {$v=trim($_POST[$key] ?? '');if($v==='' || mb_strlen($v)>$max) throw new DomainException('Заполните все поля книги.');$values[]=$v;}
   $icon=$_POST['icon'] ?? '📖';if(!in_array($icon,['📖','📚','🪄','📕','📗','✨','🐦','🏜️'],true)) $icon='📖';$values[]=$icon;
   if($id) {if(!query('SELECT id FROM books WHERE id=?',[$id])->fetch()) throw new DomainException('Книга не найдена.');query('UPDATE books SET title=?,author=?,genre=?,isbn=?,icon=? WHERE id=?',[...$values,$id]);}
   else query('INSERT INTO books(title,author,genre,isbn,icon) VALUES(?,?,?,?,?)',$values);
   $target='catalog';$_SESSION['flash']='Книга сохранена.';
  } elseif($action==='delete_book') {
   if(query('SELECT id FROM loans WHERE book_id=?',[$id])->fetch() || query('SELECT id FROM requests WHERE book_id=?',[$id])->fetch()) throw new DomainException('Книга связана с заявками или выдачами. Удаление запрещено для сохранения истории.');
   query('DELETE FROM books WHERE id=?',[$id]);$target='catalog';$_SESSION['flash']='Книга удалена.';
  } elseif($action==='issue') {
   $requestId=(int)($_POST['request_id'] ?? 0);$reader=(int)($_POST['user_id'] ?? 0);$book=(int)($_POST['book_id'] ?? 0);
   $db->beginTransaction();
   // The partial unique index (SQLite) or generated unique key (MySQL) prevents double issue.
   if($requestId) {$r=query("SELECT * FROM requests WHERE id=? AND status='pending'",[$requestId])->fetch();if(!$r) throw new DomainException('Заявка уже обработана.');$reader=(int)$r['user_id'];$book=(int)$r['book_id'];}
   elseif(!query("SELECT id FROM requests WHERE user_id=? AND book_id=? AND status='pending'",[$reader,$book])->fetch()) throw new DomainException('Сначала читатель должен подать заявку на эту книгу.');
   if(!$requestId) $requestId=(int)query("SELECT id FROM requests WHERE user_id=? AND book_id=? AND status='pending'",[$reader,$book])->fetchColumn();
   if(!available($book)) throw new DomainException('Книга уже выдана.');
   query('INSERT INTO loans(user_id,book_id,request_id,issued_by,issued_at,due_at) VALUES(?,?,?,?,?,?)',[$reader,$book,$requestId,$admin['id'],date('Y-m-d'),date('Y-m-d',strtotime('+14 days'))]);
   query("UPDATE requests SET status='approved',resolved_at=CURRENT_TIMESTAMP WHERE id=?",[$requestId]);$db->commit();$_SESSION['flash']='Книга выдана на 14 дней.';
  } elseif($action==='reject') {query("UPDATE requests SET status='rejected',resolved_at=CURRENT_TIMESTAMP WHERE id=? AND status='pending'",[$id]);$_SESSION['flash']='Заявка отклонена.';}
  elseif($action==='extend') {
   $days=filter_var($_POST['days'] ?? '',FILTER_VALIDATE_INT);if($days===false || $days<1 || $days>90) throw new DomainException('Срок продления от 1 до 90 дней.');
   $db->beginTransaction();$l=query('SELECT * FROM loans WHERE id=? AND returned_at IS NULL',[$id])->fetch();if(!$l) throw new DomainException('Активная выдача не найдена.');
   $base=max(date('Y-m-d'),$l['due_at']);query('UPDATE loans SET due_at=? WHERE id=?',[date('Y-m-d',strtotime($base.' +'.$days.' days')),$id]);$db->commit();$_SESSION['flash']='Срок чтения продлен.';
  } elseif($action==='return') {
   query('UPDATE loans SET returned_at=? WHERE id=? AND returned_at IS NULL',[date('Y-m-d'),$id]);$_SESSION['flash']='Возврат принят. Книга доступна в каталоге.';
  }
 } else {throw new DomainException('Неизвестное действие.');}
} catch(Throwable $ex) {
 if($db->inTransaction()) $db->rollBack();
 $_SESSION['error']=$ex instanceof DomainException ? $ex->getMessage() : 'Не удалось сохранить данные. Проверьте уникальность ISBN и повторите действие.';
 if(!($ex instanceof DomainException)) error_log((string)$ex);
}
redirect($target);
