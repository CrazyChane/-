<?php
// Copy to config.local.php only for hosting that cannot set environment variables.
return [
 'dsn'=>'mysql:host=localhost;dbname=library;charset=utf8mb4',
 'user'=>'YOUR_DATABASE_USER',
 'password'=>'YOUR_DATABASE_PASSWORD',
];
