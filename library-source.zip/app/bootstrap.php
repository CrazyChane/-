<?php
declare(strict_types=1);
date_default_timezone_set('Asia/Novosibirsk');
$storage=dirname(__DIR__).'/storage';
if(!is_dir($storage)) mkdir($storage,0700,true);
if(!is_dir($storage.'/sessions')) mkdir($storage.'/sessions',0700,true);
session_save_path($storage.'/sessions');
ini_set('session.use_strict_mode', '1');
session_set_cookie_params(['httponly'=>true,'samesite'=>'Lax','secure'=>!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS']!=='off']);
session_start();
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header("Content-Security-Policy: default-src 'self'; style-src 'self'; script-src 'self'; img-src 'self' data:; form-action 'self'; frame-ancestors 'none'");
$configFile=__DIR__.'/config.local.php';
$config=is_file($configFile)?require $configFile:[];
$dsn=getenv('DB_DSN') ?: ($config['dsn'] ?? 'sqlite:'.dirname(__DIR__).'/storage/library.sqlite');
$db=new PDO($dsn,getenv('DB_USER') ?: ($config['user'] ?? null),getenv('DB_PASSWORD') ?: ($config['password'] ?? null),[PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,PDO::ATTR_EMULATE_PREPARES=>false]);
if(str_starts_with($dsn,'sqlite:')) {$db->exec('PRAGMA foreign_keys=ON');$db->exec('PRAGMA busy_timeout=5000');$db->sqliteCreateFunction('LOWER',fn($s)=>mb_strtolower((string)$s,'UTF-8'),1);}
function query(string $sql,array $params=[]): PDOStatement {global $db;$s=$db->prepare($sql);$s->execute($params);return $s;}
function e($value): string {return htmlspecialchars((string)$value,ENT_QUOTES,'UTF-8');}
function user(): ?array {return empty($_SESSION['uid'])?null:(query('SELECT id,name,email,role FROM users WHERE id=?',[$_SESSION['uid']])->fetch() ?: null);}
function requireUser(bool $admin=false): array {$u=user();if(!$u || ($admin && $u['role']!=='admin')) {http_response_code(403);exit('Доступ запрещен');}return $u;}
function csrf(): string {return $_SESSION['csrf'] ??= bin2hex(random_bytes(32));}
function csrfField(): string {return '<input type="hidden" name="csrf" value="'.csrf().'">';}
function redirect(string $page='catalog'): void {header('Location: /?page='.urlencode($page),true,303);exit;}
function available(int $id): bool {return !(bool)query('SELECT id FROM loans WHERE book_id=? AND returned_at IS NULL',[$id])->fetchColumn();}
function dateLabel(string $date): string {return date('d.m.Y',strtotime($date));}
function overdue(string $date): int {return max(0,(int)floor((strtotime(date('Y-m-d'))-strtotime($date))/86400));}
