'use strict';
let previousFocus;
function openDialog(id) {
 const dialog=document.getElementById(id);
 if(!dialog) return;
 previousFocus=document.activeElement;
 dialog.showModal();
}
document.addEventListener('click',event=>{
 const open=event.target.closest('[data-open]');
 if(open) openDialog(open.dataset.open);
 const switcher=event.target.closest('[data-switch]');
 if(switcher) {switcher.closest('dialog').close();openDialog(switcher.dataset.switch);}
 const close=event.target.closest('.close,[data-close]');
 if(close) close.closest('dialog').close();
});
document.querySelectorAll('dialog').forEach(d=>d.addEventListener('close',()=>previousFocus?.focus()));
