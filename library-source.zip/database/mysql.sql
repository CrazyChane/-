-- MySQL 8.0+ / MariaDB 10.6+. Select an empty database before importing.
CREATE TABLE IF NOT EXISTS users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 name VARCHAR(100) NOT NULL,
 email VARCHAR(190) NOT NULL UNIQUE,
 password_hash VARCHAR(255) NOT NULL,
 role VARCHAR(10) NOT NULL DEFAULT 'reader',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 CHECK(role IN ('reader','admin'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS books (
 id INT AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(200) NOT NULL,
 author VARCHAR(150) NOT NULL,
 genre VARCHAR(80) NOT NULL,
 isbn VARCHAR(20) NOT NULL UNIQUE,
 icon VARCHAR(12) NOT NULL DEFAULT '📖',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS requests (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 book_id INT NOT NULL,
 status VARCHAR(12) NOT NULL DEFAULT 'pending',
 created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
 resolved_at DATETIME NULL,
 pending_book INT GENERATED ALWAYS AS (CASE WHEN status='pending' THEN book_id ELSE NULL END) STORED,
 UNIQUE KEY one_pending_request(user_id,pending_book),
 KEY requests_status(status,created_at),
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(book_id) REFERENCES books(id),
 CHECK(status IN ('pending','approved','rejected','cancelled'))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
CREATE TABLE IF NOT EXISTS loans (
 id INT AUTO_INCREMENT PRIMARY KEY,
 user_id INT NOT NULL,
 book_id INT NOT NULL,
 request_id INT NULL UNIQUE,
 issued_by INT NOT NULL,
 issued_at DATE NOT NULL,
 due_at DATE NOT NULL,
 returned_at DATE NULL,
 active_book INT GENERATED ALWAYS AS (CASE WHEN returned_at IS NULL THEN book_id ELSE NULL END) STORED,
 UNIQUE KEY one_active_loan(active_book),
 KEY loans_reader(user_id,returned_at),
 FOREIGN KEY(user_id) REFERENCES users(id),
 FOREIGN KEY(book_id) REFERENCES books(id),
 FOREIGN KEY(request_id) REFERENCES requests(id),
 FOREIGN KEY(issued_by) REFERENCES users(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
